from path_length import path_length
from ga import GA 
from read_file import file_reader
from ga_solve import ga_plotter

import time
from tabulate import tabulate
from random import choice, seed, shuffle
from tqdm import tqdm 
import numpy as np
from multiprocessing import Pool
import os
import matplotlib.pyplot as plt
import seaborn


class hybrid_GA(GA):
    """
    a subclass of the a GENETIC ALGORITM class implemented with 
    a local search on each child after applying the mutation operator.
    """

    def __init__(self, data, population_template, fitness, hybrid_type = "b"):
        super().__init__(data, population_template, fitness)
        self.hybrid_type = hybrid_type


    def hill_climber(self, individual, maxiter = 10):
        """simple local search by hill-climbing. Change-operator is a city swap"""
        i = 0
        genotype = individual[:]
        fitness_old = self.fitness_func(individual, self.data)
        index = range(len(individual))

        while i < maxiter:
            swp_city1 = choice(index)
            swp_city2 = choice(index)

            while swp_city1 == swp_city2:
                swp_city1 = choice(index)

            copy_genotype = np.copy(genotype)
            copy_genotype[swp_city1], copy_genotype[swp_city2] = copy_genotype[swp_city2], copy_genotype[swp_city1]
            fitness_new = self.fitness_func(copy_genotype, self.data)

            if fitness_new < fitness_old:
                fitness_old, genotype = fitness_new, copy_genotype

            i +=1

        if self.hybrid_type == "l":
            return genotype, fitness_old
        elif self.hybrid_type == "b":
            return individual, fitness_old
        

    def evolve(self, generations, *args, **kwargs):
        self.generations = generations
        self.pop_size = kwargs["pop_size"]
        population = self.population_template
        self.metadata = np.zeros((generations, 2))

        for i in range(int(self.generations)):
            parents = self.parent_selection(population, *args, **kwargs)

            children = self.mutation(self.recombination(parents, *args, **kwargs), *args, **kwargs)
            hill_climb_child = np.apply_along_axis(self.hill_climber, 1, children)

            tmp = np.zeros(parents.shape)
            for j in range(parents.shape[0]):
                tmp[j] = hill_climb_child[:,0][j]

            children = tmp
            children_fitness = hill_climb_child[:,1]  

            population_fitness = np.apply_along_axis(self.fitness_func, 1, population, self.data)
            all_indiviuals = np.concatenate([population, children])
            all_fitness = np.concatenate([population_fitness, children_fitness])

            population = self.survivor_selection(all_indiviuals, all_fitness, i, *args, **kwargs)

        return population, self.metadata


def ga_exe(data, num_cities, num_generations, pop_size, size_par = 0.7, p_mut = 0.8, mu = 2, fitness = path_length):

    population_template = np.zeros((pop_size, num_cities))
    genotype_template = np.arange(num_cities)

    #initialization of the population as a random distribution of genotypes from the solution space
    for i in range(int(pop_size)):
        np.random.shuffle(genotype_template)
        population_template[i] = np.copy(genotype_template)

    init_ga = hybrid_GA(data, population_template, fitness)
    solution, best_fits = init_ga.evolve(num_generations,
                                k = int(pop_size*size_par),
                                mu = mu, 
                                pop_size = pop_size,
                                p_mut = p_mut)

    return solution, best_fits


def iteration(var_in):
    """
    Function that is mapped to a worker-pool by multiprocess
    """    
    x = var_in
    
    solution_local = [[] for i in range(number_of_cities)]
    metadata_local = [[] for i in range(number_of_cities)]

    for i in range(number_of_cities):
        solution_fitness = np.apply_along_axis(path_length, 1, solution, data)
        solution_local[i] = np.array(solution_fitness)
        metadata_local[i] = np.array(metadata)

    solution_local = solution_local
    metadata_local = metadata_local

    return solution_local, metadata_local

def execute():
    global ind
    global pop_size

    for i in range(len(pop_sizes)):
        solution_all[i] = [[] for i in range(number_of_cities)]
        metadata_all[i] = [[] for i in range(number_of_cities)]

    for i, x in tqdm(enumerate(pop_sizes)):
        ind = i
        pop_size = x    
        output = None
        try:
            #multiprocess to handle computation somewhat more efficiently
            pool = Pool(os.cpu_count())
            output = pool.map(iteration, [x for x in range(num_simul)])
            output = np.array(output)   

        finally:
            #cleaning up workers
            pool.close()
            pool.join()
        
        #output[:,0][:,i] = solutions for city i
        #output[:,1][:,i] = metadata for city i
        for i in range(number_of_cities):
            solution_all[ind][i] = output[:][:,0][:,i]
            metadata_all[ind][i] = output[:][:,1][:,i]

    print("######### Generating output ###########")

    print_bool = True
    num_cit = np.arange(start_cities, end_cities+1)
    min_vals = np.zeros(number_of_cities)
    max_vals = np.zeros(number_of_cities)
    averages = np.zeros(number_of_cities)
    stds     = np.zeros(number_of_cities)

    string_base = "HYBRID_popsize_{}_paralell_bald_".format(pop_size)

    for ind, pop_size in tqdm(enumerate(pop_sizes)):
        for i in range(number_of_cities):
            averages[i], stds[i], min_vals[i], max_vals[i] = ga_plotter(solution_all[ind][i], 
                                                                        metadata_all[ind][i],
                                                                        data,
                                                                        pop_size,
                                                                        i + start_cities,
                                                                        num_simul,
                                                                        string_base)

        data_print = [num_cit, min_vals, max_vals, averages, stds]
        
        if print_bool:
            f = open("./tables/"+string_base+".txt", "w")
            f.write(tabulate(np.array(data_print).T.tolist(),
                            tablefmt = "latex"))
            f.close()


if __name__ == "__main__":
    filename = "european_cities.csv"
    data, names = file_reader(filename)

    num_simul = 5
    start_cities =  20
    end_cities = 24
    pop_sizes = [80]
    num_generations =  100
    number_of_cities = end_cities - start_cities +1

    solution_all = [[] for i in range(len(pop_sizes))] 
    metadata_all = [[] for i in range(len(pop_sizes))]

    ind = 0
    pop_size = 0

    execute()