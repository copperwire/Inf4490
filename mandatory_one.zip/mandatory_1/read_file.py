import numpy as np

def file_reader(filename):
	fileobj = open(filename)
	i = True
	_data = []

	for line in fileobj:
		if i:
			_names = [i.strip() for i in line.split(";")]
			i = False
		else:
			_data.append([float(i.strip()) for i in line.split(";")])
			
	fileobj.close()

	return np.array(_data), np.array(_names)

