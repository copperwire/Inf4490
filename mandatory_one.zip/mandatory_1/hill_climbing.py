

from path_length import path_length
from tsp import tsp
import numpy as np
from random import choice, seed, shuffle
from time import time
from tqdm import tqdm 
import seaborn
from tabulate import tabulate
import matplotlib.pyplot as plt


seed(time())

def hill_climb(data, genotype_init, fitness_func, maxiter = 1e3):
	"""hill_climb"""
	i = 0

	shuffle(genotype_init)
	genotype = genotype_init
	fitness_old = fitness_func(genotype_init, data)
	index = range(len(genotype_init))

	while i < maxiter:

		swp_city1 = choice(index)
		swp_city2 = choice(index)

		if swp_city1 == swp_city2:
			#update_progress(genotype, i/maxiter)
			continue

		copy_genotype = np.copy(genotype)

		copy_genotype[swp_city1], copy_genotype[swp_city2] = copy_genotype[swp_city2], copy_genotype[swp_city1]
		fitness_new = fitness_func(copy_genotype, data)

		if fitness_new < fitness_old:
			fitness_old, genotype = fitness_new, copy_genotype

		i +=1

	return genotype, np.arange(len(genotype_init) + 1)

def update_progress(numcit, workdone):
	print("\rProgress (numcit: {0:}): [{1:50s}] {2:.1f}%".format(len(numcit), '#' * int(workdone * 50), workdone*100), end="", flush=True)

def plotter(solutions, all_times, start_cities, end_cities, name, string_base, print_bool = False):	
	"""
	plotting function for presentation of data
	"""
	cities_iterate = np.arange(end_cities +1 - start_cities)
	
	averages = []
	max_vals = []
	min_vals = []
	stds     = []
	time_avgs = []

	for i in cities_iterate:
		plt.plot(solutions[:,i], "o")
		
		sigma = np.std(solutions[:,i])
		max_val = np.max(solutions[:,i])
		min_val = np.min(solutions[:,i])
		avg = np.average(solutions[:,i])
		time_avg = np.average(all_times[:,i])

		averages.append("{:.1f}".format(avg)); stds.append("{:.1e}".format(sigma));
		time_avgs.append("{:.1e}".format(time_avg));
		min_vals.append(int(min_val)); max_vals.append(int(max_val))

		plt.title(r"Distr for {} cities with $\sigma = ${:.1e}, $\mu_l =$ {:.1f}, $\mu_t$ = {:.1e}".format(
																					start_cities+i,
																					sigma,
																					avg,
																					time_avg))
		plt.xlabel("Simulation number")
		plt.ylabel("HC solution")
		plt.savefig("./images/{}_{}.pdf".format(name, start_cities + i))
		plt.cla()
		plt.clf()

	data = [cities_iterate + start_cities, min_vals, max_vals, averages, stds, time_avgs]
	
	if print_bool:
		print(tabulate(np.array(data).T.tolist(),
						tablefmt = "latex"))



if __name__ == "__main__":
	num_sim = int(100)

	filename = "european_cities.csv"
	start_cities = 6
	end_cities = 24

	hill_climb_inst = tsp(filename)

	all_solutions = np.zeros((num_sim, end_cities- start_cities + 1))
	all_times = np.zeros((num_sim, end_cities- start_cities + 1))

	#Solutions object is a datastructure with fitness and the  genotype used to produce that fitness
	for i in tqdm(range(num_sim)):
		solution, time_taken = hill_climb_inst.solve(start_cities,
													 end_cities,
													 hill_climb,
													 path_length,
													 np.arange(6)) 
		all_solutions[i]= [path_length(x, hill_climb_inst._data) for x in solution]
		all_times[i] = [time_taken["Number of cities: {}".format(x)][4:13] for x in range(start_cities, end_cities+1)]

	plotter(all_solutions, all_times, start_cities, end_cities, "hill_climb", print_bool = True)
