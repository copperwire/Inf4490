
import random
import numpy as np
from tqdm import trange
import time
from math import isnan

class GA:
    """
    a Genetic algorithm class implemented for the travelling
    salesman problem. Iterates over a set amount of generations before terminationg.
    selection, mutation and crossover operators are implemented in reference to the texbooks
    by Eiben & Smith (2015) and Marsland (2014). 
    """

    def __init__(self, data, population_template, fitness):
        self.data = data
        self.population_template = population_template
        self.fitness_func = fitness 


    def evolve(self, generations, *args, **kwargs):
        """
        core method of the class  - invokes all other methods needed to solve the problem
        """
        self.generations = generations
        self.pop_size = kwargs["pop_size"]
        population = self.population_template
        self.metadata = np.zeros([generations, 2])

        for i in range(int(self.generations)):

            parents = self.parent_selection(population, *args, **kwargs)

            children = self.mutation(self.recombination(parents, *args, **kwargs), *args, **kwargs)
            all_individuals = np.concatenate([children, population])
            all_fitnes = np.apply_along_axis(self.fitness_func, 1, all_individuals, self.data)
            
            population = self.survivor_selection(all_individuals, all_fitnes, i, *args, **kwargs)

        return population, self.metadata


    def parent_selection(self, population, *args, **kwargs):
        """
        weighted random selection of parents
        """

        k = kwargs["k"]
        if k%2:
            k -= 1

        parent_fitness = np.apply_along_axis(self.fitness_func, 1, population, self.data )
        relative_prob = 1 - parent_fitness/np.sum(parent_fitness)
        relative_prob = relative_prob/sum(relative_prob)

        chosen = population[np.random.choice(np.arange(population.shape[0]), 
                                            size = k, 
                                            replace  = False, 
                                            p = relative_prob)]

        return chosen

    def mutation(self, children, *args, **kwargs):
        """
        city swap mutation 
        """
        p_mut = kwargs["p_mut"]
        cp_ch = np.copy(children)

        genotype_ind = np.arange(children[0].shape[0])

        for indiv in children:
            if random.random() < p_mut:
                swp_1, swp_2 = np.random.choice(genotype_ind, 2, replace = False)
                indiv[swp_1], indiv[swp_2] = indiv[swp_2], indiv[swp_1]

        return children

    def recombination(self, parents, *args, **kwargs):
        
        children = self.pmx(parents, *args, **kwargs)
        return children

    def survivor_selection(self, all_individuals, all_fitness, i, *args, **kwargs):
        survivors = self.tournament_select(all_individuals, all_fitness, i, *args, **kwargs)
        return survivors


    def pmx(self, parents, *args, **kwargs):
        num_par, num_cities = parents.shape
        num_par_half = num_par//2

        crossover_points = np.random.choice(np.arange(num_cities), size  = (num_par_half, 2), replace = True)
        
        parent_pairs = parents[np.random.choice(np.arange(num_par), 
                                                size = (num_par_half, 2),
                                                replace  = False)]
        
        children = np.zeros((num_par, num_cities))
        children[:] = np.nan

        order = [[0, 1], [1, 0]]
        sum_thing = num_cities*(num_cities + 1)/2 

        for o in order:
            for i in range(num_par_half):

                i_c = i + o[0]*num_par_half
                u, v = crossover_points[i]
                
                while u == v:
                    v = random.choice(np.arange(num_cities))

                if u > v:
                    u,v = v, u

                parent_1 = parent_pairs[i][o[0]]
                parent_2 = parent_pairs[i][o[1]]

                child = [None]*len(parent_1)
                # Do the insertion
                child[u:v] = parent_1[u:v]
                # Map u:v slice in parent 2 to parent 1 by their indices in parent 1 :
                for ind,x in enumerate(parent_2[u:v]):
                    ind += u
                    if x not in child:
                        while child[ind] != None:
                            ind = parent_2.tolist().index(parent_1[ind])
                        child[ind] = x
                #fill out
                for ind,x in enumerate(child):
                    if x == None:
                        child[ind] = parent_2[ind]

                children[i_c] = child

        return children

    def roulette(self, children, parents, i, *args, **kwargs):
        """
        Roulette wheel selection
        """

        pop_size = self.pop_size

        select_base = np.concatenate([children, parents])
        base_fitness = np.apply_along_axis(self.fitness_func, 1, select_base, self.data ) 

        elite = np.min(base_fitness)
        self.metadata[i] = elite 
        
        base_prob =  1 - base_fitness/np.sum(base_fitness)
        relative_prob = base_prob/np.sum(base_prob)
        chosen = select_base[np.random.choice(np.arange(select_base.shape[0]), 
                                            size = pop_size, 
                                            replace = True, 
                                            p = relative_prob)]

        #Random element replaced with best so far
        chosen[random.choice(np.arange(pop_size))] = select_base[np.where(base_fitness == elite)][0]  

        return chosen


    def tournament_select(self, all_individuals, all_fitness, i, *args, **kwargs):
        """
        k-element tournament selection 
        """

        pop_size = self.pop_size
        mu = kwargs["mu"]
        gamma = pop_size

        selected = np.zeros(self.population_template.shape)
        elite = np.min(all_fitness)
        self.metadata[i] = (elite, np.std(all_fitness))          
        #print(all_fitnes)
        #print(all_individuals)

        current_member = 0

        while current_member < gamma:
            tournament_pool = np.random.choice(np.arange(all_individuals.shape[0]), 
                                                                        size = mu,
                                                                        replace = False)
            selected[current_member] = random.choice(
                                            all_individuals[
                                            np.where(
                                            np.min(all_fitness[tournament_pool]) == all_fitness)])
            current_member += 1

        #selected[random.choice(np.arange(pop_size))] = all_individuals[np.where(all_fitnes == elite)][0]  

        return selected 












