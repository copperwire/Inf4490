import unittest
import numpy as np
from ga import GA

class TestGaMethods(unittest.TestCase):

	def test_mutation(self):

		parents = np.array([[1, 2,6, 5,3, 4], [3, 2,5, 1,6, 4], [5,4,6, 2, 1, 3], [1, 4, 3, 6, 2,5]])
		
		children = GA(None, None, None).mutation(parents, p_mut = 1)
		is_correct = np.all([np.unique(i).shape[0] == parents.shape[1] for i in children])

		self.assertTrue(is_correct)


	def test_permutation(self):
		parents = np.array([[1, 2,6, 5,3, 4], [3, 2,5, 1,6, 4], [5,4,6, 2, 1, 3], [1, 4, 3, 6, 2,5]])

		children = GA(None, None, None).recombination(parents)
		is_correct = np.all([np.unique(i).shape[0] == parents.shape[1] for i in children])

		self.assertTrue(is_correct)
	



if __name__ == "__main__":
	unittest.main()