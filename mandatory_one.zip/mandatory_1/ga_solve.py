
from path_length import path_length
from ga import GA 
from read_file import file_reader

import time
from tabulate import tabulate
from random import choice, seed, shuffle
from tqdm import tqdm 
import numpy as np
from multiprocessing import Pool
import os
import matplotlib.pyplot as plt
import seaborn


def ga_exe(data, num_cities, num_generations, pop_size, size_par = 0.7, p_mut = 0.8, mu = 2, fitness = path_length):

	population_template = np.zeros((pop_size, num_cities))
	genotype_template = np.arange(num_cities)

	#initialization of the population as a random distribution of genotypes from the solution space
	for i in range(int(pop_size)):
		np.random.shuffle(genotype_template)
		population_template[i] = np.copy(genotype_template)

	init_ga = GA(data, population_template, fitness)
	solution, best_fits = init_ga.evolve(num_generations,
	 							k = int(pop_size*size_par),
	 							mu = mu, 
	 							pop_size = pop_size,
	 							p_mut = p_mut)

	return solution, best_fits

def ga_plotter(solutions_in, metadata_in, data, pop_size, num_cit, num_sim, string_base):			
	"""
	Plotting funtion for a city repeated num_sim simulations
	"""

	solutions = np.array([item for subl in solutions_in for item in subl]) 
	metadata = np.average(metadata_in, axis = 0)

	average = np.average(solutions)
	std = np.std(solutions)
	min_val = np.min(solutions)
	max_val = np.max(solutions)

	plt.subplot2grid((2, 2), (0, 0), colspan = 2, rowspan = 1).plot(solutions, "o",
														label = "Final population")


	plt.title("{}_numcit_{}".format(string_base, num_cit))
	plt.legend(fancybox = True)
	plt.subplot2grid((2, 2), (1, 0), colspan = 1).plot(metadata[:,0], "r", 
														label = "Most fit individual")
	plt.legend(fancybox = True)
	plt.subplot2grid((2, 2), (1, 1), colspan = 1).plot(metadata[:,1], "g", 
														label = "Standard deviation of population")

	plt.legend(fancybox = True)
	
	plt.savefig("./images/{}_numcit_{}.pdf".format(string_base, num_cit))
	
	plt.clf()
	plt.cla()

	return average, std, min_val, max_val

def iteration(var_in):
	"""
	target  for the worker pool made by a multiprocess Pool object mapped to an iterable 
	over the number of independent trials
	"""
	x = var_in
	
	solution_local = [[] for i in range(number_of_cities)]
	metadata_local = [[] for i in range(number_of_cities)]

	for i in range(number_of_cities):
		solution, metadata = ga_exe(data, i+start_cities, num_generations, pop_size)
		#print("whole", time.time()- start)
		solution_fitness = np.apply_along_axis(path_length, 1, solution, data)

		solution_local[i] = np.array(solution_fitness)
		metadata_local[i] = np.array(metadata)

	solution_local = solution_local
	metadata_local = metadata_local

	return solution_local, metadata_local

def execute():
	"""
	Solution and data-extraction of a GA solution of the TSP 
	"""
	global ind
	global pop_size

	for i in range(len(pop_sizes)):
		solution_all[i] = [[] for i in range(number_of_cities)]
		metadata_all[i] = [[] for i in range(number_of_cities)]

	for i, x in tqdm(enumerate(pop_sizes)):
		ind = i
		pop_size = x	
		output = None
		try:
			pool = Pool(os.cpu_count())
			output = pool.map(iteration, [x for x in range(num_simul)])
			output = np.array(output)  	

		finally:
			pool.close()
			pool.join()
		
		#output[ind][:,0][:,i] = solutions for city i
		#output[ind][:,1][:,i] = metadata for city i
		for i in range(number_of_cities):
			solution_all[ind][i] = output[:][:,0][:,i]
			metadata_all[ind][i] = output[:][:,1][:,i]

	print("######### Generating output ###########")

	print_bool = True
	num_cit = np.arange(start_cities, end_cities+1)
	min_vals = np.zeros(number_of_cities)
	max_vals = np.zeros(number_of_cities)
	averages = np.zeros(number_of_cities)
	stds     = np.zeros(number_of_cities) 

	
	for ind, pop_size in tqdm(enumerate(pop_sizes)):
		string_base = "GA_popsize_{}_paralell".format(pop_size)

		for i in range(number_of_cities):
			averages[i], stds[i], min_vals[i], max_vals[i] = ga_plotter(solution_all[ind][i], 
																		metadata_all[ind][i],
																		data,
																		pop_size,
																		i + start_cities,
																		num_simul,
																		string_base)

		data_print = [num_cit, min_vals, max_vals, averages, stds]
		
		if print_bool:
			f = open("./tables/{}.txt".format(string_base), "w")
			f.write(tabulate(np.array(data_print).T.tolist(),
							tablefmt = "latex"))
			f.close()



if __name__ == "__main__":
	filename = "european_cities.csv"
	data, names = file_reader(filename)

	num_simul = 20
	start_cities =  23
	end_cities = 24
	pop_sizes = [ 80]
	num_generations = 100  
	number_of_cities = end_cities - start_cities +1

	solution_all = [[] for i in range(len(pop_sizes))] 
	metadata_all = [[] for i in range(len(pop_sizes))]

	ind = 0
	pop_size = 0

	execute()