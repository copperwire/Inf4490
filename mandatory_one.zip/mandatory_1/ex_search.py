#self written modules for the task

from path_length import path_length
from tsp import tsp

#useful modules
from itertools import permutations
import numpy as np
from tqdm import tqdm 

def exhaust_search(data, genotype_init, fitness_func):
	"""exhaust_search"""

	opt_sol = (np.inf, None)
	genotype_template = genotype_init
	city_permutations = permutations(genotype_template)
	first = True
	dominator = None

	for permutation in tqdm(city_permutations):
		
		if first:
			dominator = permutation[0]
			first = False

		if permutation[0] != dominator:
			continue

		#Path length is a fintess evaluation tool for the current 
		current_path_lenght = fitness_func(permutation, data)
		
		if current_path_lenght < opt_sol[0]: 
			opt_sol = (current_path_lenght, permutation)

	return opt_sol[1], np.arange(len(genotype_template) + 1)


filename = "european_cities.csv"
start_cities = 6
end_cities = 10

ex_search_inst = tsp(filename)

ex_search_inst.solve(start_cities, end_cities, exhaust_search, path_length, np.arange(start_cities)) 
