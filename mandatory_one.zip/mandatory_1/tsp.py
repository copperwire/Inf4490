from read_file  import file_reader

import numpy as np
import time
import json

class tsp:

    def __init__(self, datafile):
                
        self.filename = datafile

        self._data, self._names = file_reader(self.filename)

        self.num_cities = len(self._names)

        self.copy_cities = list(self._names[:])

    def solve(self, start_cities, end_cities, solve_alg, fitness_func, gen_temp):

        current_cities = start_cities
        end_cities = end_cities

        genotype_template = gen_temp

        time_taken = {}
        
        solutions = []

        while current_cities <= end_cities:
            
            start = time.time()
            opt_sol, genotype_template = solve_alg(self._data, genotype_template, fitness_func)
            time_val = time.time() - start
            solutions.append(opt_sol)
            
            json_arg = "Time {:.2e} | Distance: {:.1f}".format(time_val, fitness_func(opt_sol, self._data))
            time_taken["Number of cities: {}".format(current_cities)] =  json_arg

            current_cities += 1

        with open("runtime_{}.json".format(solve_alg.__doc__), "w") as outfile:
            json.dump(time_taken, outfile, sort_keys = True, indent = 4, separators = (",", ":"))

        return solutions, time_taken
