import numpy as np
from read_file import file_reader

def path_length(genotype, data):
	path_length = 0

	for i in range(np.shape(genotype)[0] - 1):
		path_length += data[genotype[i]][genotype[i+1]]

	path_length += data[genotype[-1]][genotype[0]] 

	return path_length

if __name__ == "__main__":
	filename = "european_cities.csv"
	data, names = file_reader(filename)

	genotype = np.arange(6)
	print(path_length(genotype, data))
